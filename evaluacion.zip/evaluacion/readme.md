## Se inicia un proyecto con Laravel 5.4 y mongodb v3.0.15 
## comando artisan 'app:usuariosSinCobros' [Obtiene los usuarios sin cobros el dia en curso y notificar la cantidad de usuarios por mail, solo la cantidad.]
## diagrama UML.png
## Para restaurar db por consola ejecutar: mongorestore dump/ 